const {app} = require('electron')
const path = require('path')
//const os = require('os')

function getPluginFileName(opts = {}) {
  opts = Object.assign({swiftshader: false, nocap: false}, opts)
  let s = 'ppapi_voip'
  if (process.platform !== 'win32') {
    s = 'lib'+s
  }
  if (opts.swiftshader) {
    s += '_swiftshader'
  } else if (opts.nocap) {
    s += '_nocap'
  }
  s += '_'
  if (process.arch === 'x64') {
    if (process.platform === 'win32' || process.platform === 'darwin') {
      s += 'x64'
    } else if (process.platform === 'linux') {
      s += 'x86_64'
    }
  } else {
    s += 'x86'
  }
  if (process.platform === 'darwin') {
    s += '.dylib'
  } else if (process.platform === 'win32') {
    s += '.dll'
  } else if (process.platform === 'linux') {
    s += '.so'
  }
  return s
}

function containsNonASCII(str) {
  for (let i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) > 255) {
      return true;
    }
  }
  return false;
}

function workaroundForPluginPath(fullPluginPath) {
  let pluginPath = fullPluginPath
  if (containsNonASCII(fullPluginPath)) {
    pluginPath = path.relative(process.cwd(), fullPluginPath);
    if (process.platform === 'linux') {
      if (path.dirname(pluginPath) === '.') {
        pluginPath = `.${path.sep}${pluginPath}`;
      }
      if (containsNonASCII(pluginPath)) {
        loge('ERROR: non-ASCII plugin path is not supported')
      }
    }
    if (process.platform === 'win32') {
      process.chdir(process.cwd())
      loge('WARNING: non-ASCII plugin path is not well supported, voip may not work')
    }
  }
  return pluginPath
}

function getPluginPaths() {
  let dir
  if (!process.env.HOT) {
    dir = path.join(path.dirname(__dirname), 'dist')
  } else {
    dir = path.join(path.join(__dirname, '..'), 'bin', 'voip')
    if (process.env.VOIP_DEBUG) {
      dir = path.join(dir, 'debug')
    }
  }
  let paths = {
    gl:          workaroundForPluginPath(path.join(dir, getPluginFileName())),
    swiftshader: workaroundForPluginPath(path.join(dir, getPluginFileName({swiftshader: true})))
  }
  if (process.platform === 'darwin') {
    paths['gl-nocap'] = workaroundForPluginPath(path.join(dir, getPluginFileName({nocap: true})))
  }
  return paths
}

function registerPlugin() {
  let libs = getPluginPaths()
  let plugins = []
  for (let key in libs) {
      let lib = libs[key]
      plugins.push(`${lib};application/x-voip-${key}`)
  }
  console.log('plugins:', plugins.join(','))
  app.commandLine.appendSwitch('register-pepper-plugins', plugins.join(','))
}


module.exports = {
  registerPlugin
}
